package org.planning.Assign;

import java.sql.Connection;

public class CustomerDAO {
	
public static int addNewCustomer(Customer e) {
		
		// establish connection
		int result = 0;
		Connection con = DBHelper.getConnection();
		
		// is the emp obj ready? Yes ...we got it in the parameter
		
		// create and initialize your prepared statement
		
	//	int res = execute the statement and collect the resulkt
		
		
		return result;
	}

}
