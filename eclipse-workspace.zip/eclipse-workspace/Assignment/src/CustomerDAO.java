import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CustomerDAO {
	


public static int addNewCustomer(Customer c) throws SQLException {
	// TODO Auto-generated method stub
	int result = 0;
	Connection con = DBHelper.getConnection();

	Statement stat = con.createStatement();

	
	String insertQuery="insert into customer values ('gfh','Raman','25000','yfh')";
	stat.execute(insertQuery);
	System.out.println(insertQuery);
	return result;
}


}
