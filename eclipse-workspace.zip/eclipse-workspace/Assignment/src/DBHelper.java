import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBHelper {
	
	
		private static Connection con;
		
		public static Connection getConnection() {
			try {    
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/company","root","root");
			
			}catch(SQLException e) {
				
			}
			return con;

		}}
