import java.sql.SQLException;
import java.util.Scanner;

public class Driver {
	
	public static int addNewCustomer()
	{ 
	//	int result = CustomerDAO.addNewCustomer(c);
		
		
		return 0;
	}
	
	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);
		Customer c = new Customer();
		//c.setAddress();
		int result = CustomerDAO.addNewCustomer(c);
		System.out.println(result);
		
	
}

	
		
			
			
			

			
			
			
			
		
		
		



}
