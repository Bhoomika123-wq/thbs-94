
public class Shipment {

}
