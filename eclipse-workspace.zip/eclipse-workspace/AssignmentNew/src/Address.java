
public class Address {
	private String firstLine;
	private String secondLine;
	private String landMark1;
	private String landMark2;
	private String area;
	private String city;
	private String pin;
	
	
	public String getFirstLine() {
		return firstLine;
	}
	public void setFirstLine(String firstLine) {
		this.firstLine = firstLine;
	}
	public String getSecondLine() {
		return secondLine;
	}
	public void setSecondLine(String secondLine) {
		this.secondLine = secondLine;
	}
	public String getLandMark1() {
		return landMark1;
	}
	public void setLandMark1(String landMark1) {
		this.landMark1 = landMark1;
	}
	public String getLandMark2() {
		return landMark2;
	}
	public void setLandMark2(String landMark2) {
		this.landMark2 = landMark2;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}

}
