public class Customer {



private int cid;
private String cname;
private String email;
private String phone;
private Address caddress;


public Customer(int cid, String cname, String email, String phone, Address caddress) {
super();
this.cid = cid;
this.cname = cname;
this.email = email;
this.phone = phone;
this.caddress = caddress;
}










public Customer() {
super();
}









public Customer(int id, String name, String email2, String phone2) {
// TODO Auto-generated constructor stub
}









public int getCid() {
return cid;
}





public void setCid(int cid) {
this.cid = cid;
}





public String getCname() {
return cname;
}





public void setCname(String cname) {
this.cname = cname;
}





public String getEmail() {
return email;
}





public void setEmail(String email) {
this.email = email;
}





public String getPhone() {
return phone;
}





public void setPhone(String phone) {
this.phone = phone;
}





public Address getCaddress() {
return caddress;
}





public void setCaddress(Address caddress) {
this.caddress = caddress;
}




@Override
public String toString() {
return "Customer [cid=" + cid + ", cname=" + cname + ", email=" + email + ", phone=" + phone + ", caddress="
+ caddress + "]";
}



}