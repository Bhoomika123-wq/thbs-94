import java.sql.Connection;
import java.sql.PreparedStatement;



public class CustomerDAO {



public static boolean insertCustomer(Customer cr) {
boolean f=false;

try {

Connection con = DBCONN.createC();

String q= "insert into customer(cid, cname, email, phone) values(?, ?, ?, ?)";

PreparedStatement p = con.prepareStatement(q);
//set the values of paramaters
p.setInt(1, cr.getCid());
p.setString(2, cr.getCname());
p.setString(2, cr.getEmail());
p.setString(2, cr.getPhone());

p.executeUpdate();
f=true;

}catch(Exception e) {
e.printStackTrace();
}
return f;



}



}