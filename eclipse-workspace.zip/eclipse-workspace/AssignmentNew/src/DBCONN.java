
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;public class DBCONN {
static Connection con;
public static Connection createC() {
try {
Class.forName("com.mysql.cj.jdbc.Driver");
String url = "jdbc:mysql://localhost:3306/company";
String userName = "root";
String password = "root";
con = DriverManager.getConnection(url, userName, password);
}catch(Exception e) {
e.printStackTrace();
}
return con;
}
}

