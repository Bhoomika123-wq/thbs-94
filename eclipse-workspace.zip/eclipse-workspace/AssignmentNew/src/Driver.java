import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;



public class Driver {




public static void main(String[] args) throws IOException {

BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

while(true) {

Ui.menu();

int c = Integer.parseInt(br.readLine());

if(c==1) {

System.out.println("Enter customer customerId");
int id = Integer.parseInt(br.readLine());

System.out.println("Enter customer customerName");
String name = br.readLine();

System.out.println("Enter customer Email");
String email = br.readLine();

System.out.println("Enter customer Phone");
String phone = br.readLine();

Customer cr = new Customer(id, name, email, phone);
boolean ans = CustomerDAO.insertCustomer(cr);
if(ans) {
System.out.println("Done");
}else {
System.out.println("fail");
}
System.out.println(cr);



}
else if(c==2) {


}
else if(c==3) {
;

}
else if(c==4) {


}
else if(c==5) {


}
else if(c==6) {
break;

}
else {


}
}
System.out.println("Thank You");
System.out.println("See You Soon");
}

/*
* public static int acceptChoice() { return 0;
*
* }
*
* public static Customer addNewCust() { Customer c = new Customer();
* c.setCid(1); c.setCname("Shrenik"); c.setEmail("s@gmail.com");
* c.setPhone("8887878"); c.setCaddress(null);
*
* int result= CustomerDAO.addNewCustomer(c);
*
* if (result == 1) { System.out.println("success"); } else {
* System.out.println("error");
*
* }
*
*
* Address a = new Address(); a.setFirstLine("aaaa"); a.setSecondLine(null);
* a.setArea(null); a.setCity(null); a.setLandMark(null); a.setCountry(null);
*
* }
*/




}
