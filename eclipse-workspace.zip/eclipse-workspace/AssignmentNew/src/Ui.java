
public class Ui {
	public static void menu() {
		System.out.println("\t\t\t ============================");
		System.out.println("\t\t\t Weclome to SpedFast Couriers");
		System.out.println("\t\t\t ============================");
		System.out.println("");
		System.out.println("1. Add New Customer");
		System.out.println("2. Add New Shipment");
		System.out.println("3. Add New Greeting Shipment");
		System.out.println("4. Add New Payment");
		System.out.println("5. Add New Priority");
		System.out.println("6. EXIT");
		
		
	}

}
