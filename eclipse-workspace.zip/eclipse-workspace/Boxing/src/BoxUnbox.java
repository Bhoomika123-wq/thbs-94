import java.util.Scanner;

public class BoxUnbox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
	//Integer iobj1 = sc.nextInt();
	//System.out.println("enter no");
	//System.out.println(iobj1);
		
		Integer iobj = new Integer(10);
		int i = iobj;
		Float fobj = new Float(3.9);
		Double dobj = new Double(2.9);
		Byte bobj = new Byte((byte)5);
		Boolean blobj = new Boolean(true);
		Short sobj = new Short((short) 7);
		Long lobj = new Long(4353);
		Character cobj = new Character('b');
		
		System.out.println("int"+iobj);
		System.out.println("float"+fobj);
		System.out.println("double"+dobj);
		System.out.println(bobj);
		System.out.println(blobj);
		System.out.println(sobj);
		System.out.println(lobj);
		System.out.println(cobj);
		
		

	}

}
