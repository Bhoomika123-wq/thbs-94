

/*public class BoxDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Box b = new Box();
		b.initialize(2,3,4);
		b.display();
		System.out.println(b.getVolume());
		System.out.println(b.hashCode());
		System.out.println(b);

	}

}*/
