
public class Car {
	private String name;
	private String fuelType;
	private int engineCapacity;
	private double power;
	private String carType;
	private int noOfGears;
	
	static int noOfWeels=4;
	
	
	static {
		System.out.println("static block");
	}
	public Car(String name, String fuelType, int engineCapacity, double power, String carType, int noOfGears) {
		this.name = name;
		this.fuelType = fuelType;
		this.engineCapacity = engineCapacity;
		this.power = power;
		this.carType = carType;
		this.noOfGears = noOfGears;
		
		System.out.println("inside constructor");
	}
	
	void displayFeature()
	{
		System.out.println("car name"+name);
		System.out.println("fuel type"+fuelType);
		System.out.println("engine capacity"+engineCapacity+"cc");
		System.out.println("power"+power+"BHP");
		System.out.println("car type"+carType);
		System.out.println("no of gears"+noOfGears);
	}
	public void accelerate()
	{
		System.out.println(name+"car is accelerating...");
		
	}
	public void steer()
	{
		System.out.println(name+"car is changing direction...");
		
		
	}
	public void changeGear()
	{
		System.out.println(name+"car is changing gear...");
	}
	public void applyBrake()
	{
		System.out.println(name+"car is slowing down...");
	}
	
	public String getName()
	{
	return this.name;	
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	public double getPower()
	{
	  return this.power=power;	
	}
	public void setPower(double power)
	{
		this.power=power;
	}

	public String getFuelType() {
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public int getEngineCapacity() {
		return engineCapacity;
	}

	public void setEngineCapacity(int engineCapacity) {
		this.engineCapacity = engineCapacity;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public int getNoOfGears() {
		return noOfGears;
	}

	public void setNoOfGears(int noOfGears) {
		this.noOfGears = noOfGears;
	}

	@Override
	public String toString() {
		return "Car [name=" + name + ", fuelType=" + fuelType + ", engineCapacity=" + engineCapacity + ", power="
				+ power + ", carType=" + carType + ", noOfGears=" + noOfGears + "]";
	}
	
	public void method1()
	{
		System.out.println("m1");
		
	}
	public void method2()
	{
		System.out.println("m2");
		
	}
	
}
