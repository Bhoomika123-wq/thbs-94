
public class CarDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Car duster = new Car("Duster","Diesel",1500,95.4,"suv",5);
      Car nano = new Car("Tata nano","petrol", 640,60.2,"mini Suv",4);
      
      
      duster.displayFeature();
      
      
      nano.displayFeature();
      
      duster.accelerate();
      duster.applyBrake();
      duster.changeGear();
      duster.steer();
      System.out.println(duster.getName());
      
      duster.setName("Renault duster");
      System.out.println(duster.getName());
      
System.out.println("before"+duster.getPower());
      
      duster.setPower(65.0);
      System.out.println("after"+duster.getPower());
      
      duster.noOfWeels=5;
      System.out.println(duster.noOfWeels);
	}

}
