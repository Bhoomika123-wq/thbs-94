
public class CarInheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HatchBack swift = new HatchBack("ms swift" , "petrol",1200,85.4,"HatchBack",5,21.4);

		Sedan verna = new Sedan("Hyundi","petrol",1500,97.8,"sedan",5,400,"Haram");
		swift.displayFeature();
		verna.displayFeature();
		
		Suv s1 = new Suv("suv","petrol",1200,85.4,"suv",5,"Eco",true);
		Suv s2 = new Suv("suv","petrol",1200,85.4,"suv",5,"city",true);
		Suv s3 = new Suv("suv","petrol",1200,85.4,"suv",5,"sports",true);
		
		Car c = new Suv("suv","petrol",1200,85.4,"suv",5,"Eco",true);
		
		c.method2();
		c.method2();
		//c.method3(;)
		
		s1.accelerate();
		s2.accelerate();
		s3.accelerate();
		
		System.out.println(s1);
		System.out.println(s2);
		
	}

}
