
public class Employee {
private String name;
private int empId;
private String designation;
int salary;
int sumAssured=0;
public Employee(String name, int empId, String designation, int salary) {
	this.name = name;
	this.empId = empId;
	this.designation = designation;
	this.salary = salary;
	//this.sumAssured=sumAssured;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getSumAssured() {
	return sumAssured;
}
public void setSumAssured(int sumAssured) {
	this.sumAssured = sumAssured;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
@Override
public String toString() {
	return "Employee [name=" + name + ", empId=" + empId + ", designation=" + designation + ", salary=" + salary
			+ ", sumAssured=" + sumAssured + "]";
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
void displayEmpFeatures()
{
	System.out.println("emp name:"+name);
	System.out.println("emp id :"+empId);
	System.out.println("emp desig :"+designation);
	System.out.println("emp sal :"+salary);
	
}

int increment(int hike )
{
	 salary=(this.salary*(hike)/100)+salary;
	return salary;
}

}
