
public class EmployeeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp1 = new Employee("Ram",101,"HR",35000);
		Employee emp2 = new Employee("Shyam",102,"Software engineer",45000);
		Employee emp3 = new Employee("Seeta",103,"Senior Software engineer ",85000);
  
		//display emp data
	System.out.println("1."+emp1.getName()+"..details");
		emp1.displayEmpFeatures();
		System.out.println(emp2.getName()+"..details");
		emp2.displayEmpFeatures();
		System.out.println(emp3.getName()+"..details");
		emp3.displayEmpFeatures();
		
		//display name and salary 
		System.out.println(emp1.getName());
		System.out.println("before increment"+emp1.getSalary());
		//emp1.setSalary(45000);
		//System.out.println("before increment"+emp1.getSalary());
		
		/*System.out.println("after"+emp1.increment(10));
		System.out.println("before increment"+emp2.getSalary());
		System.out.println("after"+emp2.increment(20));
		System.out.println("before increment"+emp2.getSalary());
		System.out.println("before increment"+emp3.getSalary());
		System.out.println("after"+emp3.increment(30));
		
		Insurance i1 =new Insurance("lic","Health");
		Insurance i2 =new Insurance("lic","term");
		
		i1.assignInsurance(emp1);
		System.out.println("sum assured"+emp1.getSumAssured());
		
		i2.assignInsurance(emp2);
		System.out.println("sum assure"+emp2.getSumAssured());*/
		
		Manager m1 = new Manager("Ram",101,"manager",55000,2,"seeta");
		TechLead t1 = new TechLead("Shym",102,"techlead",45000,10,"Heart disease prediction");
		SoftwareEngineer s1 = new SoftwareEngineer("Radha",103,"SE",45000,"Gym Management","Python") ;
		
		m1.callMeeting();
		m1.displayEmpFeatures();
		
		t1.AssignTask();
		t1.displayEmpFeatures();
		
		s1.commitCode();
		s1.displayEmpFeatures();
		
		System.out.println(emp1);
		System.out.println(emp2);
		System.out.println(emp3);
		
		
		
		
	}

}
