import java.util.Scanner;

public class EmployeeNew {

	private static  int id;
	private static double sal;
	
	public static void main(String[] args) {
		
Scanner sc = new Scanner(System.in);
		
		System.out.println("enter val");
		id = sc.nextInt();
		sal= sc.nextDouble();
		// TODO Auto-generated method stub
//EmployeeNew2 e1 = new EmployeeNew2(id, sal);
		if(id!=0&& sal>2500)
		{
			
			System.out.println(id);
			
			System.out.println(EmployeeNew.sal);
			
			System.out.println("valid");
		}
		else
		{
			System.out.println("invalid");
		}
		
	}

}
