
public class HatchBack extends Car{
	private double mileage;

	public HatchBack(String name, String fuelType, int engineCapacity, double power, String carType, int noOfGears, double milage) {
		super(name, fuelType, engineCapacity, power, carType, noOfGears);
		// TODO Auto-generated constructor stub
		
		this.mileage=mileage;
	}

	public double getMileage() {
		return mileage;
	}

	public void setMileage(double mileage) {
		this.mileage = mileage;
	}
	public void displayFeature() {
		super.displayFeature();
		System.out.println(mileage);
	
		
	}

	
	

}
