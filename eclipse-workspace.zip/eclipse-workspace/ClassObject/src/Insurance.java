
public class Insurance {

	private String name;
	private String type;
	public Insurance(String name, String type) {
		this.name = name;
		this.type = type;
	}
	
	void assignInsurance(Employee em)
	{
		if(type.equals("Health"))
		{
			em.setSumAssured((6*(em.getSalary())));
			//em.setSalary(ins);
		}
		else if(type.equals("term"))
		{
			em.setSumAssured(5*(em.getSalary())*12);
			
		}
		
	}
}
