
public class Manager extends Employee {
	
	int noOfProjects;
	String clientName;

	public Manager(String name, int empId, String designation, int salary,int noOfProjects,String clientName) {
		super(name, empId, designation, salary);
		// TODO Auto-generated constructor stub
		this.clientName=clientName;
		this.noOfProjects=noOfProjects;
	}

	public int getNoOfProjects() {
		return noOfProjects;
	}

	public void setNoOfProjects(int noOfProjects) {
		this.noOfProjects = noOfProjects;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	
	void callMeeting() {
		System.out.println("manager calling for meeting");
	}
	
	void displayEmpFeatures()
	{
		super.displayEmpFeatures();
		System.out.println("client name:"+clientName);
		System.out.println("project no :"+noOfProjects);
		
		
	}

}
