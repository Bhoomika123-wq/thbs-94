
public class Rectangle extends Shape {
	
	private int length;
	private int height;

	public Rectangle(int length, int height) {
		setNoOfSides(3);
		this.length = length;
		this.height = height;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public Rectangle() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void area() {
		// TODO Auto-generated method stub
		System.out.println((length*height));
	}

}
