
public class Sedan extends Car {
	private int bootspace;
	private String musicSystem;
	
	

	public Sedan(String name, String fuelType, int engineCapacity, double power, String carType, int noOfGears, int bootspace,String musicSystem) {
		super(name, fuelType, engineCapacity, power, carType, noOfGears);
		// TODO Auto-generated constructor stub
		this.bootspace=bootspace;
		this.musicSystem=musicSystem;
	}



	public int getBootspace() {
		return bootspace;
	}



	@Override
	public String toString() {
		return "Sedan ["+super.toString()+ bootspace + ", musicSystem=" + musicSystem + "]";
	}



	public void setBootspace(int bootspace) {
		this.bootspace = bootspace;
	}



	public String getMusicSystem() {
		return musicSystem;
	}



	public void setMusicSystem(String musicSystem) {
		this.musicSystem = musicSystem;
	}
	public void displayFeature() {
		super.displayFeature();
		System.out.println(bootspace);
		System.out.println(musicSystem);
		
	}

}
