
public class ShapeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Triangle t1 = new Triangle(10,20);
		t1.area();
		
		Rectangle r1 = new Rectangle(30,40);
		r1.area();
		
		Shape s1 = new Triangle(2,3);
		s1.area();
		
		Shape s2 = new Rectangle(2,2);
		s2.area();

	}

}
