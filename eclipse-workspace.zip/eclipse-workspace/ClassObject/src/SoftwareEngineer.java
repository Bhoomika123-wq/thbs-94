
public class SoftwareEngineer extends Employee {
	
	String ProjectName;
	String skill;

	public SoftwareEngineer(String name, int empId, String designation, int salary,String ProjectName,String skill) {
		super(name, empId, designation, salary);
		// TODO Auto-generated constructor stub
		this.ProjectName=ProjectName;
		this.skill=skill;
	}
	
	void commitCode() {
		System.out.println("coding....");
	}
	
	void displayEmpFeatures()
	{
		super.displayEmpFeatures();
		System.out.println("project name:"+ProjectName);
		System.out.println("skill:"+ skill);
		
		
	}
}
