
public class Suv extends Car{
	
	String driveMode;
	boolean sunRoad;
	public Suv(String name, String fuelType, int engineCapacity, double power, String carType, int noOfGears,String driveMode,boolean sunRoad) {
		super(name, fuelType, engineCapacity, power, carType, noOfGears);
		// TODO Auto-generated constructor stub
		
		this.driveMode = driveMode;
		this.sunRoad = sunRoad;
	}
	public void accelerate()
	{
		
		if(driveMode.equals("Eco"))
		{
			System.out.println(this.getName()+"is "+"accelerating "+"in "+driveMode+" slowly");
		}
		
		else if(driveMode.equals("city"))
		{
			System.out.println(this.getName()+ " is"+" accelerating"+" in"+ driveMode+" moderatly");
			
		}
		else if(driveMode.equals("sports"))
		{
			System.out.println(this.getName()+"is"+" accelerating"+" in"+ driveMode+" rapidly");
			
		}
		
		
		
		
	}
	
	public void method3()
	{
		System.out.println("m3");
		
	}
	

}
