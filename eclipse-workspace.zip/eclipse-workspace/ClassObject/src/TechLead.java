
public class TechLead extends Employee {
	
	int teamSize;
	String ProjectName;

	public TechLead(String name, int empId, String designation, int salary,int teamSize,String ProjectName) {
		super(name, empId, designation, salary);
		// TODO Auto-generated constructor stub
		this.teamSize=teamSize;
		this.ProjectName=ProjectName;
	}
	void AssignTask() {
		System.out.println("Assigned task");
	}
	
	void displayEmpFeatures()
	{
		super.displayEmpFeatures();
		System.out.println("team size :"+teamSize);
		System.out.println("project name :"+ProjectName);
		
		
	}


}
