import java.util.ArrayList;
import java.util.Comparator;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Integer> ilist =new ArrayList<>();
		
		ilist.add(10);
		ilist.add(20);
		ilist.add(30);
		ilist.add(40);
		ilist.add(2,50);
		
		System.out.println(ilist);
		ilist.remove(2);
		ilist.sort(null);
		System.out.println(ilist);
		
		ArrayList<String> slist =new ArrayList<>();
		slist.add("Ram");
		slist.add("shyam");
		slist.add("Ram");
		slist.add("Radha");
		System.out.println(slist);
		
		
		ArrayList<Employee> elist =new ArrayList<>();
		
		Employee e1 = new Employee(101,"Ram","manager",35000);
		Employee e2 = new Employee(102,"shyam","Hr",55000);
		Employee e3 = new Employee(103,"Radh","manager",45000);
		//elist.sort((Comparator<? super Employee>) e1);
		elist.add(e1);
		elist.add(e2);
		elist.add(e3);
	
		
		System.out.println(elist);
		
	;
		System.out.println(elist);
		
		for(Employee e : elist)
			System.out.println(e);
		
		ArrayList<Person> plist =new ArrayList<>();
		
		Person p1 = new Person("Ram",35,"HR", "Bangalore");
		Person p2 = new Person("shyam",25,"Software engineer", "Bangalore");
		Person p3 = new Person("Radha",30,"Manager", "Bangalore");
		
		plist.add(p1);
		plist.add(p2);
		plist.add(p3);
		plist.sort(null);
		
		for(Person p : plist)
			System.out.println(p);
		System.out.println();
		
		System.out.println("using comparator by name");
		elist.sort(new EmployeeSortByNameComparator());
		for(Employee e : elist)
			System.out.println(e);
		System.out.println();
		
		System.out.println("using comparator by sal");
		elist.sort(new EmployeeSortBySalaryComparator());
		for(Employee e : elist)
			System.out.println(e);
		elist.sort(new EmployeeSortBySalaryComparator());
		
		
		
		
		
		
		
	}
		
		

}
