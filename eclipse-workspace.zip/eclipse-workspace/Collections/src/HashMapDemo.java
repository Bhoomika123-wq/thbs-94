import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap<Integer,String> hm = new HashMap<>();
		hm.put(101, "Ram");
		hm.put(102, "Seeta");
		hm.put(103, "Shym");
		//System.out.println(hm);
		
		for(Entry<Integer, String> entry:hm.entrySet() ) {
			System.out.println("key"+entry.getKey()+"value"+entry.getValue());
		
		}
		
		Employee e1 = new Employee(101,"Ram","manager",35000);
		Employee e2 = new Employee(102,"shyam","Hr",55000);
		Employee e3 = new Employee(103,"Radh","manager",45000);
		
		HashMap<Integer,Employee> emphm = new HashMap<>();	
		emphm.put(e1.getEmpid(),e1);
		emphm.put(e2.getEmpid(),e2);
		
		for(Integer key:emphm.keySet())
		{
			System.out.println("key"+key+"value"+emphm.get(key));
			System.out.println();
		}
		
		HashMap<String,Person2> phm = new HashMap<String,Person2>();	
		Person2 p1 = new Person2("abc",1234,"smg");
		Person2 p2 = new Person2("def",3489,"dvg");
		Person2 p3 = new Person2("hbc",7890,"bngr");
		
		phm.put(p1.getName(), p1);
		phm.put(p2.getName(), p2);
		phm.put(p3.getName(), p3);
		
		for(String key:phm.keySet())
		{
			System.out.println("key  "+key+" value "+phm.get(key));
		}
		
		Iterator<Map.Entry<Integer,Employee>> itr = emphm.entrySet().iterator();
		
		while(itr.hasNext()) {
			Map.Entry<Integer, Employee> entry = itr.next();
			System.out.println("key"+entry.getKey()+"value"+entry.getValue());
		}
		

	}

}
