import java.util.HashSet;
import java.util.Iterator;



public class HashsetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HashSet<Integer> inths = new HashSet<Integer>();

inths.add(10);
inths.add(20);
inths.add(30);
inths.add(40);
System.out.println(inths);

HashSet<String> strhs = new HashSet<String>();
strhs.add("hello");
strhs.add("hi");
System.out.println(strhs);

  Iterator<String> itr = strhs.iterator();
  
  while(itr.hasNext())
	  System.out.println(itr.next());

  Employee e1 = new Employee(101,"Ram","manager",35000);
	Employee e2 = new Employee(102,"shyam","Hr",55000);
	Employee e3 = new Employee(103,"Radh","manager",45000);
	Employee e4 = new Employee(103,"Radh","manager",45000);
	
	HashSet<Employee> enths = new HashSet<Employee>();
	
	enths.add(e1);
	enths.add(e2);
	enths.add(e3);
	//enths.add(e3);
	enths.add(e4);
	
	System.out.println(e3.hashCode());
	
	Iterator<Employee> itr1 = enths.iterator();
	  
	  while(itr1.hasNext())
		  System.out.println(itr1.next());

		
	}

}
