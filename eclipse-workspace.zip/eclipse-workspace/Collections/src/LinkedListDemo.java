import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//queue
		LinkedList<Integer> ilnist = new LinkedList<Integer>();
	
		ilnist.add(10);
		ilnist.add(20);
		ilnist.add(30);
		ilnist.add(40);
		System.out.println(ilnist);
		ilnist.remove();
		System.out.println(ilnist);
		ilnist.remove();
		System.out.println(ilnist);
		
		ilnist.add(0, 70);
		System.out.println(ilnist);
		ilnist.removeFirst();
		System.out.println(ilnist);
		ilnist.addFirst(90);
		System.out.println(ilnist);
		ilnist.addLast(80);
		System.out.println(ilnist);
		System.out.println();
		
		
		//stack
		LinkedList<Float> flnist = new LinkedList<Float>();
		
		flnist.push(3.5f);
		flnist.push(4.5f);
		flnist.push(5.5f);
		System.out.println(flnist);
		flnist.pop();
		System.out.println(flnist);
		
		flnist.add(0, 7.8f);
		System.out.println(flnist);
		flnist.remove(0);
		System.out.println(flnist);
		flnist.peek();
		System.out.println(flnist);
		
		
		
		

	}

}
