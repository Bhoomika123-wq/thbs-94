
public class Movie implements Comparable<Movie>{

	private int mid;
	private String mname;
	private int year;
	private Double imdb;
	private int collection;
	public Movie(int mid, String mname, int year, Double imdb, int collection) {
		this.mid = mid;
		this.mname = mname;
		this.year = year;
		this.imdb =imdb;
		this.collection = collection;
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public Double getImdb() {
		return imdb;
	}
	public void setImdb(Double imdb) {
		this.imdb = imdb;
	}
	public int getCollection() {
		return collection;
	}
	public void setCollection(int collection) {
		this.collection = collection;
	}
	@Override
	public int compareTo(Movie o) {
		// TODO Auto-generated method stub
		return (this.mid- o.mid);
	}
	@Override
	public String toString() {
		return "Movie [mid=" + mid + ", mname=" + mname + ", year=" + year + ", imdb=" + imdb + ", collection="
				+ collection + "]";
	}
	
	
	
	
}
