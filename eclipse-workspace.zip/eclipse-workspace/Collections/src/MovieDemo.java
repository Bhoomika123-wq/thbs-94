import java.util.ArrayList;

public class MovieDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Movie m1 = new Movie(101,"Iron Man",2008,8.1,80);
		Movie m2 = new Movie(102,"Avengers",2012,9.3,90);
		Movie m3 = new Movie(103,"Little rascals",2001,7.9,60);
		Movie m4 = new Movie(104,"Shershaah",2021,9.5,70);
		Movie m5 = new Movie(105,"Rangi taranga",2017,8.8,50);
		Movie m6 = new Movie(106,"Dia",2020,7.9,80);
		//ArrayList<Person> plist =new ArrayList<>();
		
		ArrayList<Movie> mlist = new ArrayList<>();
		
		mlist.add(m1);
		mlist.add(m2);
		mlist.add(m3);
		mlist.add(m4);
		mlist.add(m5);
		mlist.add(m6);
		//sort by id
		mlist.sort(null);
		System.out.println("by id");
		//System.out.println(mlist);
		for(Movie m : mlist)
			System.out.println(m);
        System.out.println();
        
        System.out.println("by name");
        mlist.sort(new MovieSortByName());
        for(Movie m : mlist)
			System.out.println(m);
        System.out.println();
        
        System.out.println("by imdb");
        mlist.sort(new MovieSortByimdb());
        for(Movie m : mlist)
			System.out.println(m);
        System.out.println();
        
        System.out.println("by collection");
        mlist.sort(new MovieSortBycollection());
        for(Movie m : mlist)
			System.out.println(m);
        System.out.println();
        
		
		
	}

}
