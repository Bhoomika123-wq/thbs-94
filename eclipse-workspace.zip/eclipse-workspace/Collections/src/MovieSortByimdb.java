import java.util.Comparator;

public class MovieSortByimdb implements Comparator<Movie>{

	@Override
	public int compare(Movie o1, Movie o2) {
		// TODO Auto-generated method stub
		//return o1.getImdb().compareTo(o2.getImdb());
		
		Double r1 = o1.getImdb();
		Double r2 = o2.getImdb();
		
		return r1.compareTo(r2);
	}

}
