
public class Person2 implements Comparable<Person2> {

	private String name;
	private long adar;
	private String addr;
	
	
	
	public Person2(String name, long adar, String addr) {
		this.name = name;
		this.adar = adar;
		this.addr = addr;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public long getAdar() {
		return adar;
	}



	public void setAdar(int adar) {
		this.adar = adar;
	}



	public String getAddr() {
		return addr;
	}



	public void setAddr(String addr) {
		this.addr = addr;
	}



	@Override
	public String toString() {
		return "Person2 [name=" + name + ", adar=" + adar + ", addr=" + addr + "]";
	}



	@Override
	public int compareTo(Person2 o) {
		// TODO Auto-generated method stub
		Long adar1 = this.adar;
		Long adar2 = o.adar;
		return (adar1.compareTo(adar2)) ;
	}

}
