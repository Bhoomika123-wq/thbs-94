import java.util.Map;
import java.util.TreeMap;

public class TreeMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
TreeMap<String,Double> scores = new TreeMap<String , Double>();
	scores.put("Amar", 8.7);
	scores.put("Rahul", 8.8);
	scores.put("Disha", 9.7);
	System.out.println(scores);
	for(String key:scores.keySet())
	System.out.println("key:"+key+"value"+scores.get(key));
	
	 Employee e1 = new Employee(101,"Ram","manager",35000);
		Employee e2 = new Employee(102,"shyam","Hr",55000);
		Employee e3 = new Employee(103,"Radh","manager",45000);
		Employee e4 = new Employee(103,"Radh","manager",45000);
	
		TreeMap<Employee,String> empnames = new TreeMap<Employee, String>();
		empnames.put(e1, e1.getName());
		empnames.put(e2, e2.getName());
		
		for(Map.Entry<Employee, String> entry:empnames.entrySet())
		{
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
		}
		
	}

}
