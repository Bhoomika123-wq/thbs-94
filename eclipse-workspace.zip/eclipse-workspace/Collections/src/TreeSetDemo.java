import java.util.LinkedHashSet;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeSet<Integer> tiset = new TreeSet<Integer>();
		tiset.add(10);
		tiset.add(30);
		tiset.add(10);
		System.out.println(tiset);
		
		TreeSet<Person2> PersonTreeSet = new TreeSet<Person2>();
		
		Person2 p1 = new Person2("abc",1234,"smg");
		Person2 p2 = new Person2("def",3489,"dvg");
		Person2 p3 = new Person2("hbc",7890,"bngr");
		
		PersonTreeSet.add(p1);
		PersonTreeSet.add(p2);
		PersonTreeSet.add(p3);
		
		for(Person2 p:PersonTreeSet)
		System.out.println(p);
		System.out.println();
		
		TreeSet<Person2> PersonTreeSet1 = new TreeSet<Person2>(new PersonSortByName());
		PersonTreeSet1.add(p1);
		PersonTreeSet1.add(p2);
		PersonTreeSet1.add(p3);
		
		for(Person2 p:PersonTreeSet1)
			System.out.println(p);
		System.out.println();
		
		LinkedHashSet<Integer> ils = new LinkedHashSet<Integer>();
		ils.add(10);
		ils.add(30);
		ils.add(50);
		ils.add(20);
		
		System.out.println(ils);
		
	
		
	}

}
