package com.torryharris.driver;

import com.torryharris.exceptions.LeavesLimitExceeededException;
import com.torryharris.model.Employee;

public class EmployeeLeavesLimitExceeededExceptionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee ram = new Employee("Ram",1001,"Manager",66000,20);
	System.out.println(ram);
	
	try {
		ram.applyLeave(3);
ram.applyLeave(4);
	}catch(LeavesLimitExceeededException e) {
		System.out.println("exception");
		System.out.println(e);
	}
	
	}

}
