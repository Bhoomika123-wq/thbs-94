package com.torryharris.driver;

import com.torryharris.exceptions.InsufficientFundsExceptions;
import com.torryharris.exceptions.WithdrawLimitExceededException;
import com.torryharris.model.Bank;
import com.torryharris.model.Person;

public class PersonBankDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person p1 = new Person("Ram",636865328,7532468,"salary",1000,0);
		Person p2 = new Person("Ram",636865328,7532468,"salary",1000,55000);
		
		Bank b1 = new Bank("hdfc","Shimoga","hdfc6587758");
		
		
		try {
		
		b1.withDrawAmount(p1, 5200);
		//b1.withDrawAmount(p2, 55000);
		

	}
		catch(InsufficientFundsExceptions ie)
		{
			ie.printStackTrace();
		} catch (WithdrawLimitExceededException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(p1);
		//System.out.println(p2);
		System.out.println(p1.getTotalAmountWithdrawn());
		//System.out.println(p1.getBalance());
}
}
