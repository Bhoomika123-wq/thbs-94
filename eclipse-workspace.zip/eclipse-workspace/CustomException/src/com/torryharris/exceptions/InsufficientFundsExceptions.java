package com.torryharris.exceptions;

public class InsufficientFundsExceptions extends Exception {

	public InsufficientFundsExceptions() {
		// TODO Auto-generated constructor stub
	}

	public InsufficientFundsExceptions(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
