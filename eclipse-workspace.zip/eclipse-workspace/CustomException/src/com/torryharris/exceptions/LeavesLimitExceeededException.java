package com.torryharris.exceptions;

public class LeavesLimitExceeededException extends Exception {

	
	public LeavesLimitExceeededException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LeavesLimitExceeededException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
