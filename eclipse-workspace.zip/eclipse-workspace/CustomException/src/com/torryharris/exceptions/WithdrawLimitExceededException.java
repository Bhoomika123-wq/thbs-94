package com.torryharris.exceptions;

public class WithdrawLimitExceededException extends Exception {

	public WithdrawLimitExceededException() {
		// TODO Auto-generated constructor stub
	}

	public WithdrawLimitExceededException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
