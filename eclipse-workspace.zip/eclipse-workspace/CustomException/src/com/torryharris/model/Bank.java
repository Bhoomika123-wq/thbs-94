package com.torryharris.model;

import com.torryharris.exceptions.InsufficientFundsExceptions;
import com.torryharris.exceptions.WithdrawLimitExceededException;

public class Bank {

	private String bankName;
	private String branchLoc;
	private String ifscCode;
	public Bank(String bankName, String branchLoc, String ifscCode) {
		this.bankName = bankName;
		this.branchLoc = branchLoc;
		this.ifscCode = ifscCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBranchLoc() {
		return branchLoc;
	}
	public void setBranchLoc(String branchLoc) {
		this.branchLoc = branchLoc;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	
	public void withDrawAmount(Person p , int amount) throws WithdrawLimitExceededException, InsufficientFundsExceptions {
		if(amount>55000)
		{
			throw new WithdrawLimitExceededException("withdraw limit exceeded..");
		}
		
		else if(amount>p.getBalance())
		{
			throw new InsufficientFundsExceptions("insufficient balance");
		}
		else {
			
			//p.setTotalAmountWithdrawn(p.getTotalAmountWithdrawn()+amount);
			p.setBalance(p.getBalance()-amount);
	   
	   
		}
		System.out.println(p.getBalance());
	}
	@Override
	public String toString() {
		return "Bank [bankName=" + bankName + ", branchLoc=" + branchLoc + ", ifscCode=" + ifscCode + "]";
	}
	
}
