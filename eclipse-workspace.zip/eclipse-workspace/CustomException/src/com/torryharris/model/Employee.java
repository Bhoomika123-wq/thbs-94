package com.torryharris.model;

import com.torryharris.exceptions.LeavesLimitExceeededException;

public class Employee {
private String name;
private int emoId;
private String dsgn;
private int salary;
private int noOfLeaves;
public Employee(String name, int emoId, String dsgn, int salary, int noOfLeaves) {
	this.name = name;
	this.emoId = emoId;
	this.dsgn = dsgn;
	this.salary = salary;
	this.noOfLeaves = noOfLeaves;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getEmoId() {
	return emoId;
}
public void setEmoId(int emoId) {
	this.emoId = emoId;
}
public String getDsgn() {
	return dsgn;
}
public void setDsgn(String dsgn) {
	this.dsgn = dsgn;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public int getNoOfLeaves() {
	return noOfLeaves;
}
public void setNoOfLeaves(int noOfLeaves) {
	this.noOfLeaves = noOfLeaves;
}
@Override
public String toString() {
	return "Employee [name=" + name + ", emoId=" + emoId + ", dsgn=" + dsgn + ", salary=" + salary + ", noOfLeaves="
			+ noOfLeaves + "]";
}

public void applyLeave(int leaves) throws LeavesLimitExceeededException{
	if(noOfLeaves<1|| leaves >3||noOfLeaves<leaves) {
		throw new LeavesLimitExceeededException("invalid leaves request");
	}
	else {
		System.out.println("approved"+getName()+"for"+leaves);
	}
}

}
