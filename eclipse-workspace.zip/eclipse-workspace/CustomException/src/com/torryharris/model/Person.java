package com.torryharris.model;

public class Person {
	
private String name;
private int adar;
private int accno;
public int getAccno() {
	return accno;
}
public void setAccno(int accno) {
	this.accno = accno;
}
public Person(String name, int adar, int accno, String accType, int balance, int totalAmountWithdrawn) {
	this.name = name;
	this.adar = adar;
	this.accno = accno;
	this.accType = accType;
	this.balance = balance;
	this.totalAmountWithdrawn = totalAmountWithdrawn;
}
private String accType;
private int balance;
@Override
public String toString() {
	return "Person [name=" + name + ", adar=" + adar + ", accno=" + accno + ", accType=" + accType + ", balance="
			+ balance + ", totalAmountWithdrawn=" + totalAmountWithdrawn + "]";
}
private int totalAmountWithdrawn;
public Person(String name, int adar, String accType, int balance, int totalAmountWithdrawn) {
	this.name = name;
	this.adar = adar;
	this.accType = accType;
	this.balance = balance;
	this.totalAmountWithdrawn = totalAmountWithdrawn;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAdar() {
	return adar;
}
public void setAdar(int adar) {
	this.adar = adar;
}
public String getAccType() {
	return accType;
}
public void setAccType(String accType) {
	this.accType = accType;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}
public int getTotalAmountWithdrawn() {
	return totalAmountWithdrawn;
}
public void setTotalAmountWithdrawn(int totalAmountWithdrawn) {
	this.totalAmountWithdrawn = totalAmountWithdrawn;
}



}
