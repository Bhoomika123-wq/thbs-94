package com.torryharris.driver;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class CheckedException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			FileOutputStream out = new FileOutputStream("file.txt");
			
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
