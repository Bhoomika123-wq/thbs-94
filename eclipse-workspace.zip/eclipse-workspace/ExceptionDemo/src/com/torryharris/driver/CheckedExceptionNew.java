package com.torryharris.driver;

import java.util.Scanner;

public class CheckedExceptionNew {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a and b");
		int a = sc.nextInt();
		int b = sc.nextInt();
		try {
			if(b==0) {
				throw new ArithmeticException("dont divide by zero ");
			}else {
				System.out.println(a/b);
			}
				
		}catch(ArithmeticException e)
		{
			System.out.println(e);
		}

	}

}
