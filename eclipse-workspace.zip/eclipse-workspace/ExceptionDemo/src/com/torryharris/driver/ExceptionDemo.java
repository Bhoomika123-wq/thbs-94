package com.torryharris.driver;

import java.util.Scanner;

public class ExceptionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Scanner sc = new Scanner(System.in);
try {
System.out.println("enter a and b");
int a = sc.nextInt();
int b = sc.nextInt();
int res= a/b;
int []c= new int[4];
c[4]=10;
String str = null;

System.out.println(res);
System.out.println("exception next code...");
}
catch(ArithmeticException e) {
	System.out.println(e);
	System.out.println("handled");
}
catch(ArrayIndexOutOfBoundsException e) {
	System.out.println("array index out of bound");
	System.out.println(e);
}
catch(NullPointerException e) {
	System.out.println("null pointer");
	System.out.println(e);
	
}
catch(Exception e)
{
	System.out.println("generic exception");
}

System.out.println("hello");



	}

}
