package com.torryharris.driver;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Scanner;

public class ThrowsDemo {

	public static void createFile(String fileName) throws FileNotFoundException {
		// TODO Auto-generated method stub
		FileOutputStream out = new FileOutputStream(fileName);
        System.out.println(fileName);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter file name");
		String fileName=sc.next();
	
	try {
		createFile(fileName);
	}catch(FileNotFoundException e) {
		System.out.println(e);
		
	}

}}
