package com.torryharries.generics.driver;




public class Employee{

	private int empid;
	private String name;
	private String desig;
	private int sal;
	public Employee(int empid, String name, String desig, int sal) {
		this.empid = empid;
		this.name = name;
		this.desig = desig;
		this.sal = sal;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesig() {
		return desig;
	}
	public void setDesig(String desig) {
		this.desig = desig;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", desig=" + desig + ", sal=" + sal + "]";
	}
	
	
}
