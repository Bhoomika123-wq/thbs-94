package com.torryharries.generics.driver;


import com.torryharries.generics.model.Demo2;


public class GenericDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Demo2<Integer,Float> ifDemo2 = new Demo2<Integer , Float>(100,2.3f);

System.out.println("type of variables a :"+ifDemo2.getA().getClass().getName()+"value"+ifDemo2.getA());
System.out.println("type of variables b :"+ifDemo2.getClass().getName()+"value"+ifDemo2.getB());
System.out.println();	

Employee e1 = new Employee(101,"abc","xyz",59000);
Demo2<Employee , String> eDemo2 = new Demo2<Employee,String>();
eDemo2.setA(e1);
eDemo2.setB("String emp");

System.out.println("type of variables a :"+eDemo2.getA().getClass().getName()+"value"+eDemo2.getA());
System.out.println("type of variables b :"+eDemo2.getClass().getName()+"value"+eDemo2.getB());
System.out.println();	
	}

}
