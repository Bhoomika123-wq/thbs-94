package com.torryharries.generics.driver;

import com.torryharries.generics.model.Demo;


public class GenericsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Demo<Integer> iDemo = new Demo<Integer>();
		iDemo.a=100;
		iDemo.b=200;
		
		System.out.println("type of variables a :"+iDemo.a.getClass().getName()+"value"+iDemo.a);
		System.out.println("type of variables b :"+iDemo.b.getClass().getName()+"value"+iDemo.b);
		System.out.println();
		
		
		Demo<Float> fDemo = new Demo<Float>();
		Demo<Float> fiDemo = new Demo<Float>(3.5f,4.5f);
		
		fDemo.a=10.0f;
		fDemo.b=20.0f;
		
		System.out.println("type of variables a :"+fDemo.a.getClass().getName()+"value"+fDemo.a);
		System.out.println("type of variables b :"+fDemo.b.getClass().getName()+"value"+fDemo.b);
		System.out.println();
		
		System.out.println("type of variables a :"+fiDemo.a.getClass().getName()+"value"+fiDemo.a);
		System.out.println("type of variables b :"+fiDemo.b.getClass().getName()+"value"+fiDemo.b);
		System.out.println();
		
		
		Demo<String> sDemo = new Demo<String>();
		sDemo.a="Bhoomika";
		sDemo.b="bhoomi";
		
		System.out.println("type of variables a :"+sDemo.a.getClass().getName()+"value"+sDemo.a);
		System.out.println("type of variables b :"+sDemo.b.getClass().getName()+"value"+sDemo.b);
		System.out.println();
		
		Employee e1 = new Employee(101,"abc","xyz",59000);
		Employee e2 = new Employee(101,"abc","xyz",59000);
		Demo<Employee> eDemo = new Demo<Employee>(e1,e2);
		System.out.println("type of variables a :"+sDemo.a.getClass().getName()+"value"+e1.toString());
		
		
		
		
		
	}

}
