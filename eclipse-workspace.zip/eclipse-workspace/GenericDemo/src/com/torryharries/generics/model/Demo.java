package com.torryharries.generics.model;

public class Demo<T> {
	public T a;
	public T b;
	public Demo(T a, T b) {
		this.a = a;
		this.b = b;
	}
	
	public Demo() {
		
	}

	public T getA() {
		return a;
	}

	public void setA(T a) {
		this.a = a;
	}

	public T getB() {
		return b;
	}

	public void setB(T b) {
		this.b = b;
	}
	

}
