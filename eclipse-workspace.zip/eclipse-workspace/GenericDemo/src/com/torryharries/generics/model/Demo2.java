package com.torryharries.generics.model;

public class Demo2<T,E> {
	private T a;
	private E b;
	public Demo2() {
		
	}
	public Demo2(T a, E b) {
		this.a=a;
		this.b=b;
		
	}
	public T getA() {
		return a;
	}
	public void setA(T a) {
		this.a = a;
	}
	public E getB() {
		return b;
	}
	public void setB(E b) {
		this.b = b;
	}
	
	

}
