import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file = new File("file2.txt");
		
FileOutputStream fout = new FileOutputStream("file.txt");
String message = "my first file program";
//fout.write(message.getBytes());
for(byte b:message.getBytes()) {
	fout.write(b);
}

System.out.println("file contents are written successfully"+file.getAbsolutePath());
fout.close();
FileInputStream fin = new FileInputStream("file.txt");

byte[] filecontents=fin.readAllBytes();
String data= new String(filecontents);
System.out.println("reading contents");
System.out.println(data);



	}

}
