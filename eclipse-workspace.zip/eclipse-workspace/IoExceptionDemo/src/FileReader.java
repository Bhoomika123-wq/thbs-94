import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileReader {

	public FileReader(File file) {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
FileWriter writer = new FileWriter("file3.txt");

Scanner scanner = new Scanner(System.in);
System.out.println("enter contents");

String data = scanner.nextLine();
writer.write(data);

System.out.println("contents written onto the file");
writer.close();

File file = new File("file3.txt");
FileReader reader = new FileReader(file);

char []fileContents = new char[(int)file.length()];
reader.read(fileContents);
System.out.println(fileContents);



		
		
	}

	private void read(char[] fileContents) {
		// TODO Auto-generated method stub
		
	}

}
