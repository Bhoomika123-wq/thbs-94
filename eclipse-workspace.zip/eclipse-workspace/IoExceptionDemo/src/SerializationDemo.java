import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class SerializationDemo {

	public static void main(String[] args) throws IOException , ClassNotFoundException {
		// TODO Auto-generated method stub
		
		Employee e1 = new Employee(101,"Ram","manager",35000);
		Employee e2 = new Employee(102,"shyam","Hr",55000);
		Employee e3 = new Employee(103,"Radh","manager",45000);
		//serialization
		FileOutputStream fout = new FileOutputStream("emp.txt");
		ObjectOutputStream out = new ObjectOutputStream(fout);
	//	out.writeObject(e1);
	//	out.writeObject(e2);
		ArrayList<Employee> emp1 = new ArrayList<Employee>();
		emp1.add(e1);
		emp1.add(e2);
		emp1.add(e3);
		out.writeObject(emp1);
		System.out.println("emp data is written");
		out.close();
		fout.close();
		
		//deserialization
		FileInputStream fin = new FileInputStream("emp.txt");
		ObjectInputStream in = new ObjectInputStream(fin);
       
        ArrayList<Employee> emp2 =new ArrayList<Employee>();
        System.out.println("reading file");
        
        while(true) {
        	try {
        		emp2=(ArrayList<Employee>) in.readObject();
        	//	Employee emp =(Employee) in.readObject();
        		//System.out.println(emp);
        	}catch(EOFException ex)
        	{break;
        }
	}}}


