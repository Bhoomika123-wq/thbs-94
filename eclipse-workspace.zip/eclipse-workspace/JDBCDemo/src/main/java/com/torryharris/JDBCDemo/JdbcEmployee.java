package com.torryharris.JDBCDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcEmployee {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		Class.forName("com.mysql.cj.jdbc.Driver");

		
		String url="jdbc:mysql://localhost:3306/e_commerce";
		String userName = "root";
		String password="root";

		Connection con = DriverManager.getConnection( url,userName,password);
		System.out.println("connection established");

		
		Statement stat = con.createStatement();

		
		String insertQuery="insert into employee values (1008,'Raman',25000)";
		stat.execute(insertQuery);
		System.out.println(insertQuery);
	}

}
