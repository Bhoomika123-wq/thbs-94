package com.torryharris.JDBCDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcExample {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		//1st step load jdbc driver...
Class.forName("com.mysql.cj.jdbc.Driver");

//2ns step connect to db
String url="jdbc:mysql://localhost:3306/e_commerce";
String userName = "root";
String password="root";

Connection con = DriverManager.getConnection( url,userName,password);
System.out.println("connection established");

//3rd step
Statement stat = con.createStatement();

//4 executing queries
String updateQuery="update customer set name='Raghav' where customer_no=1001";
	stat.executeUpdate(updateQuery);
	System.out.println(updateQuery);
	System.out.println("query excecuted..");
	//insert query
	String insertQuery="insert into customer values (1008,'Raman','raman@gmail.com')";
	stat.execute(insertQuery);
	System.out.println(insertQuery);
	//select query
	String query = "select * from customer";
	ResultSet rs = stat.executeQuery(query);
	System.out.println("\n customer details");
	System.out.println("number\tname\temail");
	System.out.println("-----------------");
	while(rs.next()) {
		int customerNo = rs.getInt("customer_no");
		String name= rs.getString("name");
		String email = rs.getString("email");
		System.out.println(customerNo+"\t"+name+"\t"+email);
	}
	
	//5.close the connection
	stat.close();
	con.close();
	}

}
