package com.torryharris.jdbc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ProductDb {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
Product p1 = new Product(101,"hplaptop",58000);
Product p2 = new Product(102,"delllaptop",48000);

ArrayList<Product> productList=new ArrayList<Product>();
productList.add(p1);
productList.add(p2);



Class.forName("com.mysql.cj.jdbc.Driver");

//2ns step connect to db
String url="jdbc:mysql://localhost:3306/e_commerce";
String userName = "root";
String password="root";

Connection con = DriverManager.getConnection( url,userName,password);
System.out.println("connection established");

//3rd step
Statement stat = con.createStatement();
//inserttProductIntoDB(stat,productList);

insertProductsPreparedStatement(con,productList);

//display
ArrayList<Product> dbproducts=new ArrayList<Product>();
dbproducts = dbpdisplayProductsFromDB(stat);
System.out.println("product details");
for(Product p :dbproducts) {

System.out.println(p.getProductNo()+"\t"+p.getProductName()+"\t"+p.getPrice());
}

	}

	private static void insertProductsPreparedStatement(Connection con, ArrayList<Product> productList) throws SQLException {
		String preparedQuery = "insert into product values(?,?,?)";
		PreparedStatement pstat = con.prepareStatement(preparedQuery);
		
		for(Product p:productList) {
			
			pstat.setInt(1, p.getProductNo());
			pstat.setString(2, p.getProductName());
			pstat.setInt(3, p.getPrice());
			
			System.out.println(pstat.toString());
		}
		pstat.close();
	}
		

	private static ArrayList<Product> dbpdisplayProductsFromDB(Statement stat) throws SQLException {
		ArrayList<Product> dbproducts=new ArrayList<Product>();
		String query = "select * from product";
		ResultSet rs = stat.executeQuery(query);
		while(rs.next()) {
			dbproducts.add(new Product(rs.getInt("product_no"),rs.getString("product_name"),rs.getInt("price")));
		}
		return dbproducts;
	}

	private static void inserttProductIntoDB(Statement stat, ArrayList<Product> productList) throws SQLException {
		// TODO Auto-generated method stub
		//ArrayList<Product> productList=new ArrayList<Product>();

		for(Product p:productList) {
			String insertQuery="insert into product values("+p.getProductNo()+",'"+p.getProductName()+"',"+p.getPrice()+")";
			System.out.println(insertQuery);
			stat.execute(insertQuery);
		}
		System.out.println("products inserted");
	}

}
