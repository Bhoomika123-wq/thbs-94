package com.torryharris.jdbctask;

public class Insurance {
	
	private int insId;
	private String companyName;
	private String insType;
	public Insurance(int insId, String companyName, String insType) {
		this.insId = insId;
		this.companyName = companyName;
		this.insType = insType;
	}
	public int getInsId() {
		return insId;
	}
	public void setInsId(int insId) {
		this.insId = insId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getInsType() {
		return insType;
	}
	public void setInsType(String insType) {
		this.insType = insType;
	}
	@Override
	public String toString() {
		return "Insurance [insId=" + insId + ", companyName=" + companyName + ", insType=" + insType + "]";
	}
	

}
