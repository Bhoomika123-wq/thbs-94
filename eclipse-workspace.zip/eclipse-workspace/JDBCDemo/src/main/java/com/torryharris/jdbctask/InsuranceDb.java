package com.torryharris.jdbctask;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.torryharris.jdbc.demo.Product;

public class InsuranceDb {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		Insurance i1 = new Insurance(5001,"LIC","health");
		Insurance i2 = new Insurance(5002,"Medi-buddy","health");
		Insurance i3 = new Insurance(5003,"vidal","term");
		Insurance i4 = new Insurance(5004,"Royal sundoram","vehicle");
		Insurance i5 = new Insurance(5005,"new india","Accident");
		
		ArrayList<Insurance> insList=new ArrayList<Insurance>();
		insList.add(i1);
		insList.add(i2);
		insList.add(i3);
		insList.add(i4);
		insList.add(i5);
		
		Class.forName("com.mysql.cj.jdbc.Driver");

		
		String url="jdbc:mysql://localhost:3306/e_commerce";
		String userName = "root";
		String password="root";

		Connection con = DriverManager.getConnection( url,userName,password);

	
		Statement stat = con.createStatement();
		
		//insertinsIntoDB(stat,insList);
		
		String updateQuery="update insurance set ins_type='bike and car' where ins_id=5004";
		stat.executeUpdate(updateQuery);
		System.out.println(updateQuery);
		
		String updateQuery1="update insurance set company_name ='new india assurance' where ins_id=5005";
		stat.executeUpdate(updateQuery1);
		System.out.println(updateQuery1);
		
		
		
		//display
		ArrayList<Insurance> dbins=new ArrayList<Insurance>();
		dbins = dbpdisplayinsFromDB(stat);
		System.out.println("Insurance details");
		for(Insurance i :dbins) {

		System.out.println(i.getInsId()+"\t"+i.getCompanyName()+"\t"+i.getInsType());
		}
		
		
		
	}

	private static ArrayList<Insurance> dbpdisplayinsFromDB(Statement stat) throws SQLException {
		ArrayList<Insurance> dbins=new ArrayList<Insurance>();
		String query = "select * from insurance";
		ResultSet rs = stat.executeQuery(query);
		while(rs.next()) {
			dbins.add(new Insurance(rs.getInt("ins_id"),rs.getString("company_name"),rs.getString("ins_type")));
		}
		return dbins;
	}

	private static void insertinsIntoDB(Statement stat, ArrayList<Insurance> insList) throws SQLException {
		for(Insurance i:insList) {
			String insertQuery="insert into insurance values("+i.getInsId()+",'"+i.getCompanyName()+"','"+i.getInsType()+"')";
			System.out.println(insertQuery);
			stat.execute(insertQuery);
		
	}
		System.out.println("inslist inserted");

	}}
