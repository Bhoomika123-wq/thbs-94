package com.torryharris.mvcdemo.repository;

import java.util.List;

import com.torryharris.mvcdemo.model.Product;
import com.torryharris.mvcdemo.model.User;


public interface ProductDao {
	

	void insertProduct(Product product);
	public boolean addProduct(Product product);
	
	List<Product> getAllProduct();

}
