package com.torryharris.mvcdemo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.torryharris.mvcdemo.model.User;
@Repository
public class UserImpl implements UserDao{

	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public void insertuser(User user) {
		// TODO Auto-generated method stub
		
		entityManager.persist(user);
		
	}

	public List<User> getAllPerson() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
