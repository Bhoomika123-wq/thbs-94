package com.torryharris.mvcdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.torryharris.mvcdemo.model.Product;
import com.torryharris.mvcdemo.repository.ProductDao;
import com.torryharris.mvcdemo.repository.UserDao;
@Service
public class ProductServiceImpl implements ProductService {

	
	@Autowired
	private ProductDao productDao;
	public void insertProduct(Product product) {
		
		// TODO Auto-generated method stub
		productDao.insertProduct(product);
		
		
	}

	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return  productDao.getAllProduct();
	}

}
