package com.torryharris.mvcdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.torryharris.mvcdemo.model.User;
import com.torryharris.mvcdemo.repository.UserDao;


@Service
public class UserServiceImpl implements UserDaoService {

	@Autowired
	private UserDao userDao;
	
	public void insertuser(User user) {
		// TODO Auto-generated method stub
		
		userDao.insertuser(user);
		
	}

	public List<User> getAllPerson() {
		// TODO Auto-generated method stub
		return null;
	}

}
