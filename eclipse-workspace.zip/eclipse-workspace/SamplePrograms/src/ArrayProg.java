import java.util.Scanner;

public class ArrayProg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
				
		int []arr = new int[10];
		System.out.println("enter number");
		int n = s.nextInt();
		for(int i= 0;i<10;i++)
		{
			arr[i]= n*(i+1);
		
			
		}System.out.println("array contents are");
		for(int i= 0;i<arr.length;i++)
		{
			
			System.out.println(arr[i]);
		}

	}

}
