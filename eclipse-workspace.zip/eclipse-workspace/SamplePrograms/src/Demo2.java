
/*public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=10;
		//boolean = isprime;
		for(int i=2;i<=num/2;i++)
		{
			if(num%i==0) {
			
				System.out.println("not prime");
				
			}
		}
			
				System.out.println("prime");
			
			
		

	}

}*/
