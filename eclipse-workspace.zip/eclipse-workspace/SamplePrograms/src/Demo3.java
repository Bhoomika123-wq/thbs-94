import java.util.Scanner;

public class Demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("is it raining today");
		int num = s.nextInt();
		//boolean ans = s.nextBoolean();
		switch(num) {
		case 1:
			System.out.println("is it raining today");
			boolean ans = s.nextBoolean();
			if(ans==true)
			{
				System.out.println("yes");
			}
			else
				System.out.println("no");
				
				break;
		case 2:
			System.out.println("had breakfast");
			boolean ans1 = s.nextBoolean();
			if(ans1==true)
			{
				System.out.println("yes");
			}
			else
				System.out.println("no");
				
				break;
			
		
		
		}
		
				

	}

}
