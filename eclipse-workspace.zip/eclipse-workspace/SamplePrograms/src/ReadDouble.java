import java.util.Scanner;

public class ReadDouble {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double avg =0;
		double sum=0;
Scanner s = new Scanner(System.in);
int n = s.nextInt();
double d[] = new double[n];
for(int i=0;i<n;i++)
{
	
	double ds=s.nextDouble();
	d[i]=ds;
	

}
for(int i=0;i<d.length;i++)
{
	sum+= d[i];
}
avg =sum/n;
System.out.println(avg);

	}

}
