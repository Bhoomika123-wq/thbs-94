import java.util.Scanner;

public class ReadEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("enter number");
		int n = s.nextInt();
		for(int i=2;i<=n;i++)
		{
			if(i%2==0)
				System.out.println(i);
		}

	}

}
