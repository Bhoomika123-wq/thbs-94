import java.util.Scanner;

public class ReadVariable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("enterr num");
		int num = s.nextInt();
		System.out.println(num);
		System.out.println("enterr float");
		float fl = s.nextFloat();
		System.out.println(fl);
		
		

	}

}
