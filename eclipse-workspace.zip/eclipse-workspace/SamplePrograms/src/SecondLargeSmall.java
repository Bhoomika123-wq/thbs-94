import java.util.Arrays;
import java.util.Scanner;

public class SecondLargeSmall {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int large=0;
		int seclarge=0;
		int small=0;
		int secsmall=0;
		Scanner s= new Scanner(System.in);
		int []a=new int[10];
		for(int i=0;i<10;i++)
		{
			int n =s.nextInt();
			a[i]=n;
			 
			
		}
		//Arrays.sort(a);
		for(int i=0;i<10;i++)
		{
			if(large<a[i])
			{
				large=a[i];
				for(int j=0;j<10;j++)
				if(large<a[j])
				{
					seclarge=large;
					
				}
				
				
			}
			
		}
		//System.out.println(seclarge);
		for(int i=0;i<10;i++)
		{
			if(small>a[i])
			{
				small=a[i];
				for(int j=0;j<10;j++)
				if(small>a[j])
				{
					secsmall=a[j];
					
				}
				
				
			}
			
		}
		//System.out.println(seclarge);
		System.out.println(secsmall);
		//System.out.println(a.length-1);
		

	}

}
