
public class VariableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
byte b=-128;
short s= 32767;
int i = 2147483647;
long k = 672548278l;
float pi = 3.14f;
double pinew = 3.14;
char ch ='a';
boolean flag = true;

System.out.println("byte value :"+b);
System.out.println(s);
System.out.println(i);
System.out.println(k);
System.out.println(pi);
System.out.println('a');
System.out.println(flag);







	}

}
