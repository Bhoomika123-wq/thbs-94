import java.io.EOFException;
	import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
	import java.util.ArrayList;
public class Deserializeper{
	



		public static void main(String[] args) throws ClassNotFoundException, IOException {
			// TODO Auto-generated method stub
			FileInputStream fin = new FileInputStream("got.txt");
			ObjectInputStream in = new ObjectInputStream(fin);
	       
	       
	        System.out.println("reading file");
	        
	        while(true) {
	        	try {
	        		
	        		Person p=(Person) in.readObject();
	        		System.out.println(p);
	        	}catch(EOFException ex)
	        	{break;
	        }
	        }}}


