import java.io.Serializable;

public class Person implements Serializable {
	
	private static final long serialVersionUID=10L;
	private String firstName;
	private String lastName;
	private long aadar;
	private String address;
	public Person(String firstName, String lastName, long aadar, String address) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.aadar = aadar;
		this.address = address;
	}
	@Override
	public String toString() {
		return "Person [firstName=" + firstName + ", lastName=" + lastName + ", aadar=" + aadar + ", address=" + address
				+ "]";
	}
	
	

}
