import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializePerson {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Person p1 = new Person("john","snow",12345,"Stark");
		Person p2 = new Person("Danerys","Targerian",1788345,"Targerian");
		
		FileOutputStream fout = new FileOutputStream("got.txt");
		ObjectOutputStream out = new ObjectOutputStream(fout);
		
		out.writeObject(p1);
		out.writeObject(p2);
		System.out.println("info written");
		out.close();
		fout.close();
	}

}
