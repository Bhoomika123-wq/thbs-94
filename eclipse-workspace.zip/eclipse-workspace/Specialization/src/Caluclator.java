
public class Caluclator {
	
	
	int num1;
	int num2;
	
int add(int num1, int num2) {
	int res= num1+num2;
	return res;
	
}
int sub(int num1, int num2) {
	int res= num1-num2;
	return res;
	
}

}
