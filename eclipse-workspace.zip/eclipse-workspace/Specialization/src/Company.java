
public class Company {
	
private	String name;
private	String emai;
	private String phone;
private	Address a;
	public Company(String name, String emai, String phone, Address a) {
		this.name = name;
		this.emai = emai;
		this.phone = phone;
		this.a = a;
	}
	
	public Company() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmai() {
		return emai;
	}

	public void setEmai(String emai) {
		this.emai = emai;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Address getA() {
		return a;
	}

	public void setA(Address a) {
		this.a = a;
	}

	@Override
	public String toString() {
		return "Company [name=" + name + ", emai=" + emai + ", phone=" + phone + ", a=" + a + "]";
	}
	

}
