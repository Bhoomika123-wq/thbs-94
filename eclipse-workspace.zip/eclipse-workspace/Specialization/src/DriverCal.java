
public class DriverCal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Caluclator c1 = new Caluclator();
		System.out.println(c1.add(10,20));

	}

}
