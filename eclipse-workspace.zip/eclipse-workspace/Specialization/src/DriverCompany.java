
public class DriverCompany {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Address a = new Address();
		a.setAddLine1("Vasanth nagar ");
		a.setAddLine2("sonata tower");
		a.setCity("Bangalore");
		a.setState("karnataka");
		a.setPincode("57202");
		
		Company c = new Company("thbs","thbs@gamil.com","725482",a);
		
		System.out.println(c);
	}

}
