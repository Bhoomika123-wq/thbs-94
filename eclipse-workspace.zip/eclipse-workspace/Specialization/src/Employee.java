
public class Employee {
	
	private String id;
	private String name;
	private  String email;
	
	

	public Employee() {
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee e1 = new Employee();
		e1.email="new@gmail.com";
//System.out.println(e1.email);
	}

}
