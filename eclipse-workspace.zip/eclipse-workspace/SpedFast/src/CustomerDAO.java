import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CustomerDAO {
	
	public static int addNewCustomer(Customer cust) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		Connection con = DBHelper.getConnection();
		int result = 0;
		try {
			
			
			String sql="insert into customer values(?,?,?,?,?,?,?,?,?,?,?,?);";
			PreparedStatement stat= con.prepareStatement(sql);
			
			stat.setInt(1,cust.getCustId());
			stat.setString(2,cust.getCustName());
			stat.setString(3,cust.getCustMail());
			stat.setString(4,cust.getCustPhone());
			stat.setString(5,cust.getCustStatus());
			stat.setString(6,cust.getCustAddress().getAddressLine1());
			stat.setString(7,cust.getCustAddress().getAddressLine2());
			stat.setString(8,cust.getCustAddress().getLandMark1());
			stat.setString(9,cust.getCustAddress().getLandMark2());
			stat.setString(10,cust.getCustAddress().getArea());
			stat.setString(11,cust.getCustAddress().getCity());
			stat.setString(12,cust.getCustAddress().getPin());
			
			stat.execute();
			System.out.println(stat.getUpdateCount());
			System.out.println(result);
			result = stat.getUpdateCount();
			System.out.println(result);
				
		}catch(Exception e) {
			System.out.println(e);
			
		}
		// ??
		return result;
		
	}

}
