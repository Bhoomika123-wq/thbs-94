
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBHelper {

	 

	public static Connection getConnection() throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
		Connection con=null;
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			String url = "jdbc:mysql://localhost:3306/deltafast";
			String userName = "root";
			String password = "root";
			con = DriverManager.getConnection(url, userName, password);
			
			return con;
	
	}
	
	

}