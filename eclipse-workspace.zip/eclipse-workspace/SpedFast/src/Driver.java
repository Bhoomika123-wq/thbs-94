import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class Driver {
	
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException  {
		// TODO Auto-generated method stub

		//Connection con = DBHelper.getConnection();
		Customer c = new Customer();
		Address a = new Address();

Scanner sc = new Scanner(System.in);

while(true) {
	
	Ui.menu();
	System.out.println("enter choice");
	int ch = sc.nextInt();
	
	System.out.println("enter id");
	c.setCustId(sc.nextInt());
	System.out.println("enter name");
	c.setCustName(sc.next());
	System.out.println("enter phone");
c.setCustPhone(sc.next());
	System.out.println("enter mail");
	c.setCustMail(sc.next());
	System.out.println("enter statu");
	c.setCustStatus(sc.next());
//	System.out.println("enter id");
	System.out.println("enter a1");
	a.setAddressLine1(sc.next());
	System.out.println("enter a2");
	a.setAddressLine2(sc.next());
	System.out.println("enter area");
	a.setArea(sc.next());
	System.out.println("enter city");
	a.setCity(sc.next());
	System.out.println("enter l1");
	a.setLandMark1(sc.next());
	System.out.println("enter l2");
	a.setLandMark2(sc.next());
	System.out.println("enter pin");
	a.setPin(sc.next());
	c.setCustAddress(a);

	if(ch==1) {
int res = CustomerDAO.addNewCustomer(c);
		
		if(res>0) {
			System.out.println("success");
		}
		else {
			System.out.println("error");
		}
	}	
	}		
		
	}


}
