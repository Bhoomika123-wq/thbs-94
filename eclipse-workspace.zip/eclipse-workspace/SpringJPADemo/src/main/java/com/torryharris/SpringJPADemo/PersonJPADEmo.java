package com.torryharris.SpringJPADemo;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.torryharris.SpringJPADemo.config.PersonJPAConfig;
import com.torryharris.SpringJPADemo.model.Person;
import com.torryharris.SpringJPADemo.service.PersonService;


public class PersonJPADEmo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//ApplicationContext context = new AnnotationConfigApplicationContext(PersonJPAConfig.class);

		//PersonService personService = context.getBean(PersonService.class);
		
		//Person p1 = new Person(5678L,"Ram","Ayodhya",2354735L);
		//Person p2 = new Person(89686L,"Lakshman","Ayodhya",87954735L);
		
		ArrayList<Person> personList = new ArrayList<Person>();
	//	personList.add(p1);
	//.add(p2);
		
		for(Person p : personList) {
	//		personService.insertPerson(p);
		}
		System.out.println("inserted");
		
		
		System.out.println("searching");
	//	Person personFindById = personService.getPersonById(1236267L);
	//	System.out.println(personFindById);
		
	}

}
