package com.torryharris.SpringJPADemo;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.torryharris.SpringJPADemo.config.PersonJPAConfig;
import com.torryharris.SpringJPADemo.model.Person;
import com.torryharris.SpringJPADemo.model.Product;
import com.torryharris.SpringJPADemo.service.PersonService;
import com.torryharris.SpringJPADemo.service.ProductService;

public class ProductDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new AnnotationConfigApplicationContext(PersonJPAConfig.class);

		ProductService productService = context.getBean(ProductService.class);
		
		Product p1 = new Product(5,"Ayurvedic","headache","harry","xyz",123,"2pack");
		//Person p2 = new Person(89686L,"Lhman","Ayodhya",87954735L);
		
		ArrayList<Product> productList = new ArrayList<Product>();
	//	personList.add(p1);
	//.add(p2);
		
		for(Product p : productList) {
			productService.insertProduct(p);
		}
		System.out.println("inserted");
		

	}

}
