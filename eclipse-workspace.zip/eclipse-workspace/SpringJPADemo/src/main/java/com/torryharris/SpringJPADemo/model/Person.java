package com.torryharris.SpringJPADemo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="person")
public class Person {
	
	@Id
	@Column(name="aadhaar" , nullable=false)
	private long aadhaar;
	
	@Column(name="name")
	private String name;
	
	@Column(name="address")
	private String address;
	
	@Column(name="phone")
	private long phone;
	 
	public Person() {
		
	}
	
	public Person(long aadhaar, String name, String address, long phone) {
		this.aadhaar = aadhaar;
		this.name = name;
		this.address = address;
		this.phone = phone;
	}
	public long getAadhaar() {
		return aadhaar;
	}
	public void setAadhaar(long aadhaar) {
		this.aadhaar = aadhaar;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Person [aadhaar=" + aadhaar + ", name=" + name + ", address=" + address + ", phone=" + phone + "]";
	}

	
	
}
