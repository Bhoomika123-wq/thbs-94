package com.torryharris.SpringJPADemo.repository;

import java.util.List;

import com.torryharris.SpringJPADemo.model.Product;



public interface ProductDao {
	

	void insertProduct(Product product);
	
	List<Product> getAllProduct();

}
