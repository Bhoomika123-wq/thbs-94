package com.torryharris.SpringJPADemo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.torryharris.SpringJPADemo.model.Product;


@Service
public interface ProductService {
	
	
	
void insertProduct(Product product);
	
	List<Product> getAllProduct();

}
