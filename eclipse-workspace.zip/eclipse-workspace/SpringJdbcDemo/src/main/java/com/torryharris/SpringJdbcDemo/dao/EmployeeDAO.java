package com.torryharris.SpringJdbcDemo.dao;


import java.util.List;

import com.torryharris.SpringJdbcDemo.Employee;

public interface EmployeeDAO {
	
	Employee getEmployeeById(int empId);
	
	List<Employee> getAllEmloyee();
	boolean insertEmployee(Employee employee);
	boolean updateEmployee(Employee employee);
	boolean deleteEmployee(Employee employee);

}
