package com.torryharris.SpringJdbcDemo.dao;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.torryharris.SpringJdbcDemo.Employee;
import com.torryharris.SpringJdbcDemo.EmployeeMapper;

@Component
public class EmployeeDAOImpl implements EmployeeDAO {

JdbcTemplate jdbcTemplate;
	
	private final String SQL_FIND_EMPLOYEE = "select * from employee where emp_id=?";
	private final String SQL_DELETE_EMPLOYEE= "delete from employee where emp_id=?";
	private final String SQL_UPDATE_EMPLOYEE = "update employee set emp_name=? , designation=?," + "salary=?, sum_assured=? where emp_id=?";
	private final String SQL_GET_ALL_EMPLOYEE= "select * from employee";
	private final String SQL_INSERT_EMPLOYEE = "insert into employee values(?,?,?,?,?)";
	
	@Autowired
	public  EmployeeDAOImpl(DataSource dataSource)
	{
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public Employee getEmployeeById(int empID) {
		
		// TODO Auto-generated method stub
		return jdbcTemplate.queryForObject(SQL_FIND_EMPLOYEE, new Object[] {empID} , new EmployeeMapper());
	}

	public List<Employee> getAllEmloyee() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(SQL_GET_ALL_EMPLOYEE,new EmployeeMapper() );
	}

	public boolean insertEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return (jdbcTemplate.update(SQL_INSERT_EMPLOYEE ,employee.getEmpId(),employee.getName(),employee.getDesignation(),employee.getSumAssured(),employee.getSalary())>0 );
	}

	public boolean updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return (jdbcTemplate.update(SQL_UPDATE_EMPLOYEE , employee.getEmpId(),employee.getName(),employee.getDesignation(),employee.getSumAssured(),employee.getSalary())>0);
	}

	public boolean deleteEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return (jdbcTemplate.update(SQL_DELETE_EMPLOYEE,employee.getEmpId())>0);
	}

}
