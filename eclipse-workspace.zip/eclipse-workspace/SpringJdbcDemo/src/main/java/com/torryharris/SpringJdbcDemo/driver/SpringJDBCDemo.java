package com.torryharris.SpringJdbcDemo.driver;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.torryharris.SpringJdbcDemo.Employee;
import com.torryharris.SpringJdbcDemo.config.EmployeeConfig;
import com.torryharris.SpringJdbcDemo.dao.EmployeeDAO;

public class SpringJDBCDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new AnnotationConfigApplicationContext(EmployeeConfig.class);
		EmployeeDAO employeeDAO = context.getBean(EmployeeDAO.class);
		
		System.out.println("emp details");
		for(Employee emp : employeeDAO.getAllEmloyee())
		{
			System.out.println(emp);
		}
		System.out.println("search emp");
		Employee empById = employeeDAO.getEmployeeById(1001);
		System.out.println(empById);
		
		//Employee e1 = new Employee(1004,"sgfh","yyy",167687,57879);
	//	employeeDAO.insertEmployee(e1);
		System.out.println("inserted");
		for(Employee emp : employeeDAO.getAllEmloyee())
		{
			System.out.println(emp);
		}
		empById.setDesignation("hr");
		employeeDAO.updateEmployee(empById);
		System.out.println("after deleting");
		for(Employee emp : employeeDAO.getAllEmloyee())
		{
			System.out.println(emp);
		}
		
	}

}
