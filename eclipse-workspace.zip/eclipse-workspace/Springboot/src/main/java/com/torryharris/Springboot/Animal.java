package com.torryharris.Springboot;

public interface Animal {
	public void speak();

}
