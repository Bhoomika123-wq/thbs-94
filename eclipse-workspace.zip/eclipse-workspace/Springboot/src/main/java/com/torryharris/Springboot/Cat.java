package com.torryharris.Springboot;

public class Cat {
	
	public void speak() {
		System.out.println("mew");
	}

}
