package com.torryharris.Springboot;

public class Dog {
	
	public void speak() {
		System.out.println("Dog");
	}

}
