package com.torryharris.Springbootnew;

import org.springframework.stereotype.Component;

@Component
public class Body {
	private String type;
	public Body() {
		
	}
	
	public void display() {
		System.out.println("type of body "+type);
		
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}


}
