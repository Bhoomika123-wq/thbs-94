package com.torryharris.Springbootnew;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.torryharris.Springbootnew.cofig.CarConfig;
import com.torryharris.Springbootnew.cofig.LaptopConfig;

public class CarDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new AnnotationConfigApplicationContext(CarConfig.class);

		Engine en =  context.getBean(Engine.class);
		en.setType("petrol");
		Tyre tr =  context.getBean(Tyre.class);
		tr.setType("MRF");
		Body bd =  context.getBean(Body.class);
		bd.setType("metalic");
		GearBox gb = context.getBean(GearBox.class);
		gb.setType("auto");
		
		en.display();
		tr.display();
		bd.display();
		
	}

}
