package com.torryharris.Springbootnew;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Engine {
	@Autowired
	private GearBox gbox;
	public GearBox getGbox() {
		return gbox;
	}

	public void setGbox(GearBox gbox) {
		this.gbox = gbox;
	}

	private String type;
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Engine() {
		
	}
	
	public void display() {
		System.out.println("type of engine "+type);
		gbox.display();
		
	}

}
