package com.torryharris.Springbootnew;

import org.springframework.stereotype.Component;

@Component
public class GearBox {
	
	private String type;
	
	void display()
	{
		System.out.println("Gear system  "+type);
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	

}
