package com.torryharris.Springbootnew;

import org.springframework.stereotype.Component;

@Component
public class HardDisk {
	
	public HardDisk() {
		
	}
	
	void display() {
		System.out.println("hardDisk...");
	}


}
