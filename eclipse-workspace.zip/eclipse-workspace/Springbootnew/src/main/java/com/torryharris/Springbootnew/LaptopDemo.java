package com.torryharris.Springbootnew;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.torryharris.Springbootnew.cofig.LaptopConfig;

public class LaptopDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new AnnotationConfigApplicationContext(LaptopConfig.class);

		RAM ram = (RAM) context.getBean(RAM.class);
		ram.setName("samsung");
		ram.setCapacity(32);
		HardDisk hd = context.getBean(HardDisk.class);
		Processor proc = context.getBean(Processor.class);
		MotherBoard mv = context.getBean(MotherBoard.class);
		ram.display();
		hd.display();
		proc.display();
		mv.display();
	}

}
