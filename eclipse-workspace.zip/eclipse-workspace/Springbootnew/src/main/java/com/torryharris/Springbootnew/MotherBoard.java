package com.torryharris.Springbootnew;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.torryharris.Springbootnew.Processor;

@Component
public class MotherBoard {
	@Autowired
	private Processor processor;
	
	public MotherBoard() {
		
	}

	public Processor getProcessor() {
		return processor;
	}

	public void setProcessor(Processor processor) {
		this.processor = processor;
	}
	
	public void display() {
		System.out.println("motherboard");
		processor.display();
	}
	

}
