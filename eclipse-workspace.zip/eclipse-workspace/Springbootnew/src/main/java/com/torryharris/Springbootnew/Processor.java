package com.torryharris.Springbootnew;

import org.springframework.stereotype.Component;

@Component
public class Processor {
	
	public Processor() {
		
	}
	void display() {
		System.out.println("processor...");
	}


}
