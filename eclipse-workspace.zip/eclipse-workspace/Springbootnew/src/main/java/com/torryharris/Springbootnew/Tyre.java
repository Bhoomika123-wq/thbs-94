package com.torryharris.Springbootnew;

import org.springframework.stereotype.Component;

@Component
public class Tyre {
	private String type;
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Tyre() {
		
	}
	
	public void display() {
		System.out.println("type of tyre "+type);
		
	}


}
