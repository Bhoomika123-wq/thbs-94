package com.torryharris.Springbootnew.cofig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.torryharris.Springbootnew.Body;
import com.torryharris.Springbootnew.Engine;
import com.torryharris.Springbootnew.GearBox;
import com.torryharris.Springbootnew.Tyre;

@Configuration
@ComponentScan(basePackages = {"com.torryharris.Springbootnew"})
public class CarConfig {
/*	@Bean
	public Engine getEngine() {
		return new Engine();
	}
	
	@Bean
	public Tyre getTyre() {
		return new Tyre();
	}
	@Bean
	public Body getBody() {
		return new Body();
	}
	
	@Bean
	public GearBox getGearBox() {
		return new GearBox();
	}

*/
}
