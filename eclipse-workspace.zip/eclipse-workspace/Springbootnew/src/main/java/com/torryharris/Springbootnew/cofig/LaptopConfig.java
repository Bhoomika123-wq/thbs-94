package com.torryharris.Springbootnew.cofig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.torryharris.Springbootnew.HardDisk;
import com.torryharris.Springbootnew.MotherBoard;
import com.torryharris.Springbootnew.Processor;
import com.torryharris.Springbootnew.RAM;

@Configuration
@ComponentScan(basePackages = {"com.torryharris.Springbootnew"})
public class LaptopConfig {
	/*@Bean("RAM")
	public RAM getRAM() {
		return new RAM();
	}
	@Bean
	public Processor getProcessor() {
		return new Processor();
	}
	@Bean
	public HardDisk getHardDisk() {
		return new HardDisk();
	}
@Bean
public MotherBoard getMotherBoard() {
	return new MotherBoard();
}
	*/
	
	
}
