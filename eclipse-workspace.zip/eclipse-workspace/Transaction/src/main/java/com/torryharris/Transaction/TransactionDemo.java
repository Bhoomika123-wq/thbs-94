package com.torryharris.Transaction;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

//import com.torryharris.jdbctask.Insurance;

//import com.torryharris.jdbc.demo.Product;

public class TransactionDemo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

Class.forName("com.mysql.cj.jdbc.Driver");

		
		String url="jdbc:mysql://localhost:3306/company";
		String userName = "root";
		String password="root";

		Connection con = DriverManager.getConnection( url,userName,password);
		
	//	insertEmployee(con);
		insertInsuranceDetails(con);
		
	}

	private static void insertInsuranceDetails(Connection con) throws SQLException {
		// TODO Auto-generated method stub
		
		Insurance i1 = new Insurance(2001,"LIC","health");
		Insurance i2 = new Insurance(2002,"Medi-buddy","health");
		
		ArrayList<Insurance> insList = new ArrayList<Insurance>();
		
		insList.add(i1);
		insList.add(i2);
		String pQuery = "insert into insurance values(?,?,?)";
		PreparedStatement pstat = con.prepareStatement(pQuery);
		
		for(Insurance ins:insList) {
			
			pstat.setInt(1, ins.getInsuranceId());
			pstat.setString(2, ins.getInsuranceName());
			pstat.setString(3, ins.getInsuranceType());
			
			System.out.println(pstat);
			pstat.execute();
		}
		System.out.println("inserted");
		pstat.close();
		
		
	}

	private static void insertEmployee(Connection con) throws SQLException {
		// TODO Auto-generated method stub
		Employee e1 = new Employee(1001,"Ram","Manager",50000);
		Employee e2 = new Employee(1002,"shyam","tech lead",45000);
		ArrayList<Employee> empList = new ArrayList<Employee>();
		empList.add(e1);
		empList.add(e2);
		String pQuery = "insert into employee values(?,?,?,?,?)";
		PreparedStatement pstat = con.prepareStatement(pQuery);
		
		for(Employee e:empList) {
			
			pstat.setInt(1, e.getEmployeeId());
			pstat.setString(2, e.getName());
			pstat.setString(3, e.getDesignation());
			pstat.setInt(4, e.getSalary());
			pstat.setInt(5, e.getSumAssured());
			
			System.out.println(pstat);
			pstat.execute();
		}
		System.out.println("inserted");
		pstat.close();
		
	}

}
