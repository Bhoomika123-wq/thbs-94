import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Caltest {
	
public Calculator cal;
@Before
public void init() {
	
	cal = new Calculator();
	//System.out.println("before");
}
	
@Test
public void addTest() {
	
	Calculator cal = new Calculator();
	assertEquals(6,cal.add(4, 3));
	
}
@Test
public void subTest() {
	
	//Calculator cal = new Calculator();
	assertEquals(1,cal.sub(4, 3));
	
}
@Test
public void mulTest() {
	
	//Calculator cal = new Calculator();
	assertEquals(12,cal.mul(4, 3));
}
@Test
public void divTest() {
	
	//Calculator cal = new Calculator();
	assertEquals(2,cal.div(8, 4));
}
@After
public void after() {
	//System.out.println("after");
}
}
