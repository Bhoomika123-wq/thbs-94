
public class Task {
public String  toUpper(String str)
{
	return str.toUpperCase();
}

public boolean isPrime(int n)
{
for(int i=2;i<=n/2;i++) {
	if(n%i==0)
		return false;
}
return true;
}

public int getSquare(int n)
{
	int sq= n*n;
	return sq;
}

public int getMax(int a[]) {
//	int []arr = new int[10];
	
	int max = a[0];
	for(int i=0;i<a.length;i++) {
	if(max<a[i]) {
		max=a[i];
		
	
	
}}
	return max;
}}
