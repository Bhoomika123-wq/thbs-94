import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TaskTest {
	@Test
	public void upperTest() {
		
		Task t = new Task();
		assertEquals("ABC",t.toUpper("abc"));
		
	}
	
	@Test
	public void prime() {
		
		Task t = new Task();
		assertEquals(true,t.isPrime(2));
		
	}
	
	@Test
	public void square() {
		
		Task t = new Task();
		assertEquals(4,t.getSquare(2));
		
	}
	
	@Test
	public void max() {
		
		Task t = new Task();
		int []arr = new int[]{1,2,4,6};
		assertEquals(6,t.getMax(arr));
		
	}

}
